package com.FashionStore.security;

public class JwtUserDetailsService {
}
