package com.FashionStore.DTO;

public class infoPaymentDTO {
    private Long amount;
    private Long id;

    public Long getAmount() {
        return amount;
    }

    public void setAmount(Long amount) {
        this.amount = amount;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
